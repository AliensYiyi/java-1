
public class EmptyListException extends RuntimeException
{
    public EmptyListException()
    {
        super ("the list is empty") ;
    }
}
